﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalculadora
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado; //globais

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void TxtN1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void Limpar_Click(object sender, EventArgs e)
        {
            TxtN1.Text = "";
            TxtN2.Text = "";
            TxtN3.Text = "";

            TxtN1.Focus();
        }

        private void Sair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Soma_Click(object sender, EventArgs e)
        {
            if (double.TryParse(TxtN1.Text, out numero1) &&
                double.TryParse(TxtN2.Text, out numero2))
            {
                resultado = numero1 + numero2;
                TxtN3.Text = resultado.ToString();
            }

            else
                MessageBox.Show("Numeros Invalidos!");

        }

        private void Subtração_Click(object sender, EventArgs e)
        {
            if (double.TryParse(TxtN1.Text, out numero1) &&
                double.TryParse(TxtN2.Text, out numero2))
            {
                resultado = numero1 - numero2;
                TxtN3.Text = resultado.ToString();
            }

            else
                MessageBox.Show("Numeros Invalidos!");

        }

        private void Multiplicação_Click(object sender, EventArgs e)
        {
            if (double.TryParse(TxtN1.Text, out numero1) &&
                double.TryParse(TxtN2.Text, out numero2))
            {
                resultado = numero1 * numero2;
                TxtN3.Text = resultado.ToString();
            }

            else
                MessageBox.Show("Numeros Invalidos!");

        }

        private void Divisão_Click(object sender, EventArgs e)
        {
            if (double.TryParse(TxtN1.Text, out numero1) &&
                double.TryParse(TxtN2.Text, out numero2))
            {
                if (numero2 == 0)
                    MessageBox.Show("Impossivel dividir por 0.");


                else
                {
                    resultado = numero1 / numero2;
                    TxtN3.Text = resultado.ToString();
                }
            }

            else
                MessageBox.Show("Numeros Invalidos!");
        }
    }
}
