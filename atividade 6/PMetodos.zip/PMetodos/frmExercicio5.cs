﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void brtSortear_Click(object sender, EventArgs e)
        {
            Random c = new Random();
            int Inicial = Convert.ToInt32(txtNumero1.Text);
            int Final = Convert.ToInt32(txtNumero2.Text);
            int Limite = Convert.ToInt32(txtNumero3.Text);

            String Resultado = "";

            for (int i = 0; i <= Limite - 1;i++)
            {
                Resultado = Resultado + " " + c.Next(Inicial, Final);
                lblResultado.Text = Resultado;
            }
        }

      
    }
}
