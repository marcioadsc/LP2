﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a = 0;
            int b = 0;

            if (RichTxt.Text == "")
            { 
                    MessageBox.Show("Não há nada escrito.");
            }
            
            else
            
            {
                string Texto = RichTxt.Text;
                int Tamanho = RichTxt.Text.Length;

                for (a = 0; a < Tamanho; a++)
                    
                    if (char.IsNumber(Texto[a]))
                    {
                        b++;
                    }

                if (b > 0)
                    MessageBox.Show("Existe(m) " + b + " algarismo(s) neste texto.");
                else
                    MessageBox.Show("Não existe nenhum algarismo neste texto.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        { 
            int b = 0;

            if (RichTxt.Text == "")
            {
                MessageBox.Show("Não há nada escrito.");
            }

            else

            {

                foreach (char a in RichTxt.Text)

                    if (char.IsLetter(a))
                    {
                        b++;
                    }

                if (b > 0)
                    MessageBox.Show("Existe(m) " + b + " letra(s) neste texto.");
                else
                    MessageBox.Show("Não existe nenhuma letra neste texto.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int Espaco = 0;
            int a = 0;

            if (RichTxt.Text == "")
            {
                MessageBox.Show("Não há nada escrito.");
            }

            else

            {
                string Texto = RichTxt.Text;
                while (a < Texto.Length)
                {

                    if (!char.IsWhiteSpace(Texto[a]))
                    {
                        a++;
                    }

                    else
                    {
                        a++;
                        Espaco = a;
                        break;
                    }
                }

                if (Espaco > 0)
                    MessageBox.Show("O primeiro espaço fica na posição " + Espaco + ".");
                else
                    MessageBox.Show("Não existe nenhum espaço neste texto.");
            }
        }
    }
}
