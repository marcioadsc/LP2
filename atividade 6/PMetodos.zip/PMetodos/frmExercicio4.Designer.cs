﻿
namespace PMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RichTxt = new System.Windows.Forms.RichTextBox();
            this.Btn1 = new System.Windows.Forms.Button();
            this.Btn2 = new System.Windows.Forms.Button();
            this.Btn3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // RichTxt
            // 
            this.RichTxt.Location = new System.Drawing.Point(164, 37);
            this.RichTxt.Name = "RichTxt";
            this.RichTxt.Size = new System.Drawing.Size(294, 102);
            this.RichTxt.TabIndex = 0;
            this.RichTxt.Text = "";
            // 
            // Btn1
            // 
            this.Btn1.Location = new System.Drawing.Point(164, 162);
            this.Btn1.Name = "Btn1";
            this.Btn1.Size = new System.Drawing.Size(82, 42);
            this.Btn1.TabIndex = 1;
            this.Btn1.Text = "Contar algarismos";
            this.Btn1.UseVisualStyleBackColor = true;
            this.Btn1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Btn2
            // 
            this.Btn2.Location = new System.Drawing.Point(277, 162);
            this.Btn2.Name = "Btn2";
            this.Btn2.Size = new System.Drawing.Size(75, 42);
            this.Btn2.TabIndex = 2;
            this.Btn2.Text = "Procurar espaço";
            this.Btn2.UseVisualStyleBackColor = true;
            this.Btn2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Btn3
            // 
            this.Btn3.Location = new System.Drawing.Point(383, 162);
            this.Btn3.Name = "Btn3";
            this.Btn3.Size = new System.Drawing.Size(75, 42);
            this.Btn3.TabIndex = 3;
            this.Btn3.Text = "Contar letras";
            this.Btn3.UseVisualStyleBackColor = true;
            this.Btn3.Click += new System.EventHandler(this.button3_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Btn3);
            this.Controls.Add(this.Btn2);
            this.Controls.Add(this.Btn1);
            this.Controls.Add(this.RichTxt);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox RichTxt;
        private System.Windows.Forms.Button Btn1;
        private System.Windows.Forms.Button Btn2;
        private System.Windows.Forms.Button Btn3;
    }
}