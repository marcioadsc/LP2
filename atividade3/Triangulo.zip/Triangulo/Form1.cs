﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Triangulo
{
    public partial class Form1 : Form
    {
        double LadoA, LadoB, LadoC;
        public Form1()
        {
            InitializeComponent();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            txt1.Clear();
            txt2.Clear();
            txt3.Clear();
            TipoTriangulo.Clear();
            txt1.Focus();
        }

        private void Form1_Load(object sender, EventArgs e)
        {


        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txt1.Text, out LadoA) &&
               Double.TryParse(txt2.Text, out LadoB) &&
               Double.TryParse(txt3.Text, out LadoC))
            {
                if (LadoA < (LadoB + LadoC) && (LadoA > Math.Abs(LadoB - LadoC)) &&
                    LadoB < (LadoA + LadoC) && (LadoB > Math.Abs(LadoA - LadoC)) &&
                    LadoC < (LadoA + LadoB) && (LadoC > Math.Abs(LadoA - LadoB))) 
                {
                    if (LadoA == LadoB && LadoB == LadoC)
                    {
                        TipoTriangulo.Text = ("Triângulo Equilátero.");
                    }
                    else
                    if (LadoA == LadoB || LadoA == LadoC || LadoB == LadoC)
                    {
                        TipoTriangulo.Text = ("Triângulo Isósceles.");
                    }
                    else
                        TipoTriangulo.Text = ("Triângulo Escaleno.");
                }
                else
                {
                    MessageBox.Show("Não é um triângulo.");
                }
            }
            else
                MessageBox.Show("Valores inválidos.");
        }
    }
}
