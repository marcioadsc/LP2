﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PAtividade8
{
    public partial class FrmExercicio5 : Form
    {
        public FrmExercicio5()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            String Saida1 = "\n";
            String Saida2 = "\n";

            ArrayList Aluno = new ArrayList();
            Aluno.Add("Ana");
            Aluno.Add("André");
            Aluno.Add("Débora");
            Aluno.Add("Fátima");
            Aluno.Add("João");
            Aluno.Add("Janete");
            Aluno.Add("Otávio");
            Aluno.Add("Marcelo");
            Aluno.Add("Pedro");
            Aluno.Add("Thais");

            foreach (string Nomes in Aluno)
                Saida1 += Nomes + "\n";

            Aluno.Remove("Otávio");


            foreach (string Nomes in Aluno)
                Saida2 += Nomes + "\n";

            MessageBox.Show("Lista de Alunos: " + Saida1 + "\n\n" + "Lista Atualizada: " + Saida2);
        }
    }
}
