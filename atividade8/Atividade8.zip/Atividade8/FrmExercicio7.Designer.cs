﻿
namespace PAtividade8
{
    partial class FrmExercicio7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Button1 = new System.Windows.Forms.Button();
            this.LbxNomes = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // Button1
            // 
            this.Button1.Location = new System.Drawing.Point(262, 142);
            this.Button1.Name = "Button1";
            this.Button1.Size = new System.Drawing.Size(166, 75);
            this.Button1.TabIndex = 0;
            this.Button1.Text = "Adicionar nomes";
            this.Button1.UseVisualStyleBackColor = true;
            this.Button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // LbxNomes
            // 
            this.LbxNomes.FormattingEnabled = true;
            this.LbxNomes.Location = new System.Drawing.Point(449, 70);
            this.LbxNomes.Name = "LbxNomes";
            this.LbxNomes.Size = new System.Drawing.Size(320, 238);
            this.LbxNomes.TabIndex = 1;
            this.LbxNomes.Visible = false;
            // 
            // FrmExercicio7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LbxNomes);
            this.Controls.Add(this.Button1);
            this.Name = "FrmExercicio7";
            this.Text = "FrmExercicio7";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Button1;
        private System.Windows.Forms.ListBox LbxNomes;
    }
}