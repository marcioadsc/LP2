﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exercicio1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmExercicio1 objFrm1 = new FrmExercicio1();
            objFrm1.WindowState = FormWindowState.Maximized;
            objFrm1.Show();
        }

        private void exercicio2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmExercicio2 objFrm2 = new FrmExercicio2();
            objFrm2.WindowState = FormWindowState.Maximized;
            objFrm2.Show();
        }

        private void exercicio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmExercicio3 objFrm3 = new FrmExercicio3();
            objFrm3.WindowState = FormWindowState.Maximized;
            objFrm3.Show();
        }

        private void exercicio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmExercicio4 objFrm4 = new FrmExercicio4();
            objFrm4.WindowState = FormWindowState.Maximized;
            objFrm4.Show();
        }

        private void exercicio5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmExercicio5 objFrm5 = new FrmExercicio5();
            objFrm5.WindowState = FormWindowState.Maximized;
            objFrm5.Show();
        }

        private void exercicio6ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmExercicio6 objFrm6 = new FrmExercicio6();
            objFrm6.WindowState = FormWindowState.Maximized;
            objFrm6.Show();
        }

        private void exercicio7ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmExercicio7 objFrm7 = new FrmExercicio7();
            objFrm7.WindowState = FormWindowState.Maximized;
            objFrm7.Show();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
