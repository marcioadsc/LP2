﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade8
{
    public partial class FrmExercicio7 : Form
    {
        public FrmExercicio7()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            LbxNomes.Visible = true;

            string Auxiliar = "";
            int Comprimento;

            for (var i = 0; i < 4; i++)
            {
                Comprimento = 0;
                Auxiliar = Interaction.InputBox("Digite o nome na posição: " +
                    (i + 1).ToString(), "Entrada de Dados");

                if (Auxiliar == "")
                    break;

                if (Auxiliar.Length < 8)
                {
                    MessageBox.Show("Nome inválido!");
                    i--;
                }
                else
                {
                    Comprimento = (Auxiliar.Replace(" ", "")).Length;
                    LbxNomes.Items.Add("O nome: " + Auxiliar + ":" + " tem " + Comprimento + " caracteres" + ("\n"));
                }
            }
        }
    }
}
