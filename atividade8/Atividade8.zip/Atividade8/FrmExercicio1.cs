﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
namespace PAtividade8
{
    public partial class FrmExercicio1 : Form
    {
        public FrmExercicio1()
        {
            InitializeComponent();
        }

        private void BtnRecebe_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string Auxiliar = "";
            string Saida = "";

            for (var i = 0; i < vetor.Length; i++)
            {
                Auxiliar = Interaction.InputBox("Digite o número da posição:" +
                    (i + 1).ToString(), "Entrada de Dados");

                if (Auxiliar == "")
                    break;

                if (!int.TryParse(Auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido!");
                    i--;
                }
                else
                {
                    Saida = vetor[i] + "\n" + Saida;
                }
            }
            MessageBox.Show(Saida);
        }
    
    }
}
