﻿
namespace PAtividade8
{
    partial class FrmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnRecebeRev = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnRecebeRev
            // 
            this.BtnRecebeRev.Location = new System.Drawing.Point(290, 144);
            this.BtnRecebeRev.Name = "BtnRecebeRev";
            this.BtnRecebeRev.Size = new System.Drawing.Size(178, 77);
            this.BtnRecebeRev.TabIndex = 0;
            this.BtnRecebeRev.Text = "Recebe 20 Números (Com Reverse)";
            this.BtnRecebeRev.UseVisualStyleBackColor = true;
            this.BtnRecebeRev.Click += new System.EventHandler(this.BtnRecebeRev_Click);
            // 
            // FrmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtnRecebeRev);
            this.Name = "FrmExercicio2";
            this.Text = "FrmExercicio2";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnRecebeRev;
    }
}