﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade8
{
    public partial class FrmExercicio6 : Form
    {
        public FrmExercicio6()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Lbx1.Visible = true;
            
            double[,] Notas = new double[20, 3];
            string Auxiliar = "";
            double Media;

            for (int i = 0; i < 20; i++)
            {
                Media = 0;
                for (int c = 0; c < 3; c++)
                {
                    Auxiliar = Interaction.InputBox("Aluno " + (i + 1).ToString() + "-" + " informe a " +
                        (c + 1).ToString() + "° Nota", "Calcula a Média");

                    if (Auxiliar == "")
                        break;

                    if (!double.TryParse(Auxiliar, out Notas[i, c]))
                    {
                        MessageBox.Show("Número inválido!");
                        c--;
                    }

                    Media += Notas[i, c];
                }

                Lbx1.Items.Add("Aluno " + (i + 1) + ":" + "Media: " + Math.Round(Media / 3, 2) + ("\n"));

            }

        }
    }
}
