﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P0030482023004
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Btn1_Click(object sender, EventArgs e)
        {
            double[,] N = new double[4, 4];
            string aux = "";
            int a, b;

            for (a = 0; a < 4; a++)
            {
                for (b = 0; b < 4; b++)
                {
                    aux = Interaction.InputBox("Semana: " + (b + 1), "Mês: " + (a + 1));

                    if (aux == "")
                        break;

                    if (!double.TryParse(aux, out N[a, b]))
                    {
                        MessageBox.Show("Valor Inválido");
                        b--;
                    }
                }
            }
            
            double TotalS; 
            double TotalM = 0;

            for (a = 0; a < 4; a++)
            {
                TotalS = 0;
                for (b = 0; b < 4; b++)
                {
                    LbxVendas.Items.Add("Total do mês: " + (a + 1) + " Semana: " + (b + 1) + " " + N[a, b].ToString("C2") + ("\n"));
                    TotalS += N[a, b];
                }
                LbxVendas.Items.Add("Total mensal: " + TotalS.ToString("C2") + ("\n"));
                TotalM += TotalS;
            }
            LbxVendas.Items.Add("Aqui está o total quadrimensal de suas vendas: " + TotalM.ToString("C2") + ("\n"));

            LbxVendas.Visible = true;
            Btn1.Visible = false;
            BtnCN.Visible = true;
        }

        private void BtnCN_Click(object sender, EventArgs e)
        {
            Btn1.Visible = true;
            LbxVendas.Visible = false;
            LbxVendas.Items.Clear();
            BtnCN.Visible = false;
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
