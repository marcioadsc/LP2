﻿
namespace P0030482023004
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn1 = new System.Windows.Forms.Button();
            this.LbxVendas = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.BtnCN = new System.Windows.Forms.Button();
            this.BtnSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Btn1
            // 
            this.Btn1.BackColor = System.Drawing.Color.Firebrick;
            this.Btn1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Btn1.Location = new System.Drawing.Point(147, 62);
            this.Btn1.Name = "Btn1";
            this.Btn1.Size = new System.Drawing.Size(127, 73);
            this.Btn1.TabIndex = 0;
            this.Btn1.Text = "Conferir Vendas";
            this.Btn1.UseVisualStyleBackColor = false;
            this.Btn1.Click += new System.EventHandler(this.Btn1_Click);
            // 
            // LbxVendas
            // 
            this.LbxVendas.FormattingEnabled = true;
            this.LbxVendas.Location = new System.Drawing.Point(147, 141);
            this.LbxVendas.Name = "LbxVendas";
            this.LbxVendas.Size = new System.Drawing.Size(392, 303);
            this.LbxVendas.TabIndex = 1;
            this.LbxVendas.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(144, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(395, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Clique no botão abaixo para fazer o cálculo do total quadrimestral de suas vendas" +
    ".";
            // 
            // BtnCN
            // 
            this.BtnCN.BackColor = System.Drawing.Color.Firebrick;
            this.BtnCN.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.BtnCN.Location = new System.Drawing.Point(280, 62);
            this.BtnCN.Name = "BtnCN";
            this.BtnCN.Size = new System.Drawing.Size(127, 73);
            this.BtnCN.TabIndex = 3;
            this.BtnCN.Text = "Calcular novamente - Fazer novo cálculo";
            this.BtnCN.UseVisualStyleBackColor = false;
            this.BtnCN.Visible = false;
            this.BtnCN.Click += new System.EventHandler(this.BtnCN_Click);
            // 
            // BtnSair
            // 
            this.BtnSair.BackColor = System.Drawing.Color.Firebrick;
            this.BtnSair.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.BtnSair.Location = new System.Drawing.Point(413, 62);
            this.BtnSair.Name = "BtnSair";
            this.BtnSair.Size = new System.Drawing.Size(130, 73);
            this.BtnSair.TabIndex = 4;
            this.BtnSair.Text = "Fechar aplicação";
            this.BtnSair.UseVisualStyleBackColor = false;
            this.BtnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MintCream;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtnSair);
            this.Controls.Add(this.BtnCN);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LbxVendas);
            this.Controls.Add(this.Btn1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Btn1;
        private System.Windows.Forms.ListBox LbxVendas;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BtnCN;
        private System.Windows.Forms.Button BtnSair;
    }
}

