﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalario
{
    public partial class Form1 : Form
    {
        double descinss = 0;
        double descirpf = 0;
        double salbruto = 0;
        double salfamilia = 0;
        double salliquido = 0;
        int numfilhos = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            labelMensagem.Visible = true;

            if (txtnome.Text == "") 
            {
                MessageBox.Show("Insira um nome válido.");
            }
            else if (double.TryParse(mskbxSBruto.Text, out salbruto))
            {
                if (salbruto <= 800.47)
                {
                    txtAINSS.Text = "7.65%";
                    descinss = 0.0765 * salbruto;
                }
                else if (salbruto <= 1050)
                {
                    txtAINSS.Text = "8.65%";
                    descinss = 0.0865 * salbruto;
                }
                else if (salbruto <= 1400.77)
                {
                    txtAINSS.Text = "9%";
                    descinss = 0.09 * salbruto;
                }
                else if (salbruto <= 2801.56)
                {
                    txtAINSS.Text = "11%";
                    descinss = 0.11 * salbruto;
                }
                else 
                {
                    txtAINSS.Text = "Teto";
                    descinss = 308.17;
                }

                txtDINSS.Text = descinss.ToString("N2");

            }
            if (double.TryParse(mskbxSBruto.Text, out salbruto))
            {
                if (salbruto <= 1257.12)
                {
                    txtAIRPF.Text = "Isento de IRPF.";
                }
                else if (salbruto <= 2512.08)
                {
                    txtAIRPF.Text = "15%";
                    descirpf = 0.15 * salbruto;
                }
                else
                {
                    txtAIRPF.Text = "27.5%";
                    descirpf = 0.275 * salbruto;
                }

                txtDIRPF.Text = descirpf.ToString("N2");

            }
            if (int.TryParse(CbxFilhos.Text, out numfilhos))
            {
                if (salbruto <= 435.52)
                {
                    salfamilia = 22.33 * numfilhos;
                }
                else if (salbruto <= 654.61)
                {
                    salfamilia = 15.74 * numfilhos;
                }
                else
                {
                    salfamilia = 0 * numfilhos;
                }

                txtSFamilia.Text = salfamilia.ToString("N2");

                {
                    salliquido = salbruto - descinss - descirpf + salfamilia;
                    txtSLiquido.Text = salliquido.ToString("N2");

                }
            }

            else
            {
                MessageBox.Show("Preencha os campos corretamente. Reveja os dados inseridos.");
            }

            labelMensagem.Text = "Os descontos do salário ";

            if (RbtnM.Checked)
                labelMensagem.Text = labelMensagem.Text + "do Sr. " + txtnome.Text;
            else
                labelMensagem.Text = labelMensagem.Text + "da Sra. " + txtnome.Text;

            labelMensagem.Text = labelMensagem.Text + " que é ";

            if (CkbxCasado.Checked)
                labelMensagem.Text = labelMensagem.Text + "casado(a) ";
            else
                labelMensagem.Text = labelMensagem.Text + "solteiro(a) ";

            if (int.TryParse(CbxFilhos.Text, out numfilhos))

                labelMensagem.Text = labelMensagem.Text + "e que tem " + numfilhos + " filho(s) ";

            labelMensagem.Text = labelMensagem.Text + "são: ";
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtnome.Clear();
            mskbxSBruto.Clear();
            txtAINSS.Clear();
            txtAIRPF.Clear();
            txtDINSS.Clear();
            txtDIRPF.Clear();
            txtSFamilia.Clear();
            txtSLiquido.Clear();

            labelMensagem.Visible = false;
        }
    }
}
