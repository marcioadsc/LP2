﻿
namespace PSalario
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelNome = new System.Windows.Forms.Label();
            this.labelSBruto = new System.Windows.Forms.Label();
            this.labelFilhos = new System.Windows.Forms.Label();
            this.txtnome = new System.Windows.Forms.TextBox();
            this.CbxFilhos = new System.Windows.Forms.ComboBox();
            this.GpxGenero = new System.Windows.Forms.GroupBox();
            this.RbtnF = new System.Windows.Forms.RadioButton();
            this.RbtnM = new System.Windows.Forms.RadioButton();
            this.BtnCalcular = new System.Windows.Forms.Button();
            this.labelAINSS = new System.Windows.Forms.Label();
            this.labelDINSS = new System.Windows.Forms.Label();
            this.labelAIRPF = new System.Windows.Forms.Label();
            this.labelDIRPF = new System.Windows.Forms.Label();
            this.labelSFamilia = new System.Windows.Forms.Label();
            this.labelMensagem = new System.Windows.Forms.Label();
            this.labelSLiquido = new System.Windows.Forms.Label();
            this.mskbxSBruto = new System.Windows.Forms.MaskedTextBox();
            this.txtAIRPF = new System.Windows.Forms.TextBox();
            this.txtAINSS = new System.Windows.Forms.TextBox();
            this.CkbxCasado = new System.Windows.Forms.CheckBox();
            this.txtDINSS = new System.Windows.Forms.TextBox();
            this.txtDIRPF = new System.Windows.Forms.TextBox();
            this.txtSFamilia = new System.Windows.Forms.TextBox();
            this.txtSLiquido = new System.Windows.Forms.TextBox();
            this.BtnLimpar = new System.Windows.Forms.Button();
            this.GpxGenero.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelNome
            // 
            this.labelNome.AutoSize = true;
            this.labelNome.Location = new System.Drawing.Point(65, 45);
            this.labelNome.Name = "labelNome";
            this.labelNome.Size = new System.Drawing.Size(108, 13);
            this.labelNome.TabIndex = 0;
            this.labelNome.Text = "Nome do Funcionário";
            // 
            // labelSBruto
            // 
            this.labelSBruto.AutoSize = true;
            this.labelSBruto.Location = new System.Drawing.Point(65, 83);
            this.labelSBruto.Name = "labelSBruto";
            this.labelSBruto.Size = new System.Drawing.Size(67, 13);
            this.labelSBruto.TabIndex = 1;
            this.labelSBruto.Text = "Salário Bruto";
            // 
            // labelFilhos
            // 
            this.labelFilhos.AutoSize = true;
            this.labelFilhos.Location = new System.Drawing.Point(65, 124);
            this.labelFilhos.Name = "labelFilhos";
            this.labelFilhos.Size = new System.Drawing.Size(89, 13);
            this.labelFilhos.TabIndex = 2;
            this.labelFilhos.Text = "Número de Filhos";
            // 
            // txtnome
            // 
            this.txtnome.Location = new System.Drawing.Point(179, 42);
            this.txtnome.Name = "txtnome";
            this.txtnome.Size = new System.Drawing.Size(141, 20);
            this.txtnome.TabIndex = 3;
            // 
            // CbxFilhos
            // 
            this.CbxFilhos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxFilhos.FormattingEnabled = true;
            this.CbxFilhos.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6"});
            this.CbxFilhos.Location = new System.Drawing.Point(179, 121);
            this.CbxFilhos.Name = "CbxFilhos";
            this.CbxFilhos.Size = new System.Drawing.Size(141, 21);
            this.CbxFilhos.TabIndex = 5;
            // 
            // GpxGenero
            // 
            this.GpxGenero.Controls.Add(this.RbtnF);
            this.GpxGenero.Controls.Add(this.RbtnM);
            this.GpxGenero.Location = new System.Drawing.Point(412, 45);
            this.GpxGenero.Name = "GpxGenero";
            this.GpxGenero.Size = new System.Drawing.Size(206, 100);
            this.GpxGenero.TabIndex = 6;
            this.GpxGenero.TabStop = false;
            this.GpxGenero.Text = "Gênero";
            // 
            // RbtnF
            // 
            this.RbtnF.AutoSize = true;
            this.RbtnF.Location = new System.Drawing.Point(6, 53);
            this.RbtnF.Name = "RbtnF";
            this.RbtnF.Size = new System.Drawing.Size(67, 17);
            this.RbtnF.TabIndex = 7;
            this.RbtnF.Text = "Feminino";
            this.RbtnF.UseVisualStyleBackColor = true;
            // 
            // RbtnM
            // 
            this.RbtnM.AutoSize = true;
            this.RbtnM.Checked = true;
            this.RbtnM.Location = new System.Drawing.Point(6, 30);
            this.RbtnM.Name = "RbtnM";
            this.RbtnM.Size = new System.Drawing.Size(73, 17);
            this.RbtnM.TabIndex = 0;
            this.RbtnM.TabStop = true;
            this.RbtnM.Text = "Masculino";
            this.RbtnM.UseVisualStyleBackColor = true;
            // 
            // BtnCalcular
            // 
            this.BtnCalcular.Location = new System.Drawing.Point(68, 168);
            this.BtnCalcular.Name = "BtnCalcular";
            this.BtnCalcular.Size = new System.Drawing.Size(182, 33);
            this.BtnCalcular.TabIndex = 7;
            this.BtnCalcular.Text = "Calcular Descontos e Salário";
            this.BtnCalcular.UseVisualStyleBackColor = true;
            this.BtnCalcular.Click += new System.EventHandler(this.Button1_Click);
            // 
            // labelAINSS
            // 
            this.labelAINSS.AutoSize = true;
            this.labelAINSS.Location = new System.Drawing.Point(98, 290);
            this.labelAINSS.Name = "labelAINSS";
            this.labelAINSS.Size = new System.Drawing.Size(75, 13);
            this.labelAINSS.TabIndex = 8;
            this.labelAINSS.Text = "Alíquota INSS";
            // 
            // labelDINSS
            // 
            this.labelDINSS.AutoSize = true;
            this.labelDINSS.Location = new System.Drawing.Point(409, 290);
            this.labelDINSS.Name = "labelDINSS";
            this.labelDINSS.Size = new System.Drawing.Size(81, 13);
            this.labelDINSS.TabIndex = 9;
            this.labelDINSS.Text = "Desconto INSS";
            // 
            // labelAIRPF
            // 
            this.labelAIRPF.AutoSize = true;
            this.labelAIRPF.Location = new System.Drawing.Point(98, 324);
            this.labelAIRPF.Name = "labelAIRPF";
            this.labelAIRPF.Size = new System.Drawing.Size(74, 13);
            this.labelAIRPF.TabIndex = 10;
            this.labelAIRPF.Text = "Alíquota IRPF";
            // 
            // labelDIRPF
            // 
            this.labelDIRPF.AutoSize = true;
            this.labelDIRPF.Location = new System.Drawing.Point(409, 324);
            this.labelDIRPF.Name = "labelDIRPF";
            this.labelDIRPF.Size = new System.Drawing.Size(80, 13);
            this.labelDIRPF.TabIndex = 11;
            this.labelDIRPF.Text = "Desconto IRPF";
            // 
            // labelSFamilia
            // 
            this.labelSFamilia.AutoSize = true;
            this.labelSFamilia.Location = new System.Drawing.Point(98, 361);
            this.labelSFamilia.Name = "labelSFamilia";
            this.labelSFamilia.Size = new System.Drawing.Size(76, 13);
            this.labelSFamilia.TabIndex = 12;
            this.labelSFamilia.Text = "Salário Família";
            // 
            // labelMensagem
            // 
            this.labelMensagem.AutoSize = true;
            this.labelMensagem.Location = new System.Drawing.Point(98, 235);
            this.labelMensagem.Name = "labelMensagem";
            this.labelMensagem.Size = new System.Drawing.Size(59, 13);
            this.labelMensagem.TabIndex = 13;
            this.labelMensagem.Text = "Mensagem";
            this.labelMensagem.Visible = false;
            // 
            // labelSLiquido
            // 
            this.labelSLiquido.AutoSize = true;
            this.labelSLiquido.Location = new System.Drawing.Point(409, 361);
            this.labelSLiquido.Name = "labelSLiquido";
            this.labelSLiquido.Size = new System.Drawing.Size(78, 13);
            this.labelSLiquido.TabIndex = 14;
            this.labelSLiquido.Text = "Salário Líquido";
            // 
            // mskbxSBruto
            // 
            this.mskbxSBruto.Location = new System.Drawing.Point(179, 80);
            this.mskbxSBruto.Mask = "00,000.00";
            this.mskbxSBruto.Name = "mskbxSBruto";
            this.mskbxSBruto.Size = new System.Drawing.Size(141, 20);
            this.mskbxSBruto.TabIndex = 15;
            // 
            // txtAIRPF
            // 
            this.txtAIRPF.Enabled = false;
            this.txtAIRPF.Location = new System.Drawing.Point(220, 321);
            this.txtAIRPF.Name = "txtAIRPF";
            this.txtAIRPF.Size = new System.Drawing.Size(134, 20);
            this.txtAIRPF.TabIndex = 20;
            // 
            // txtAINSS
            // 
            this.txtAINSS.Enabled = false;
            this.txtAINSS.Location = new System.Drawing.Point(220, 287);
            this.txtAINSS.Name = "txtAINSS";
            this.txtAINSS.Size = new System.Drawing.Size(134, 20);
            this.txtAINSS.TabIndex = 21;
            // 
            // CkbxCasado
            // 
            this.CkbxCasado.AutoSize = true;
            this.CkbxCasado.Location = new System.Drawing.Point(418, 168);
            this.CkbxCasado.Name = "CkbxCasado";
            this.CkbxCasado.Size = new System.Drawing.Size(74, 17);
            this.CkbxCasado.TabIndex = 22;
            this.CkbxCasado.Text = "Casado(a)";
            this.CkbxCasado.UseVisualStyleBackColor = true;
            // 
            // txtDINSS
            // 
            this.txtDINSS.Enabled = false;
            this.txtDINSS.Location = new System.Drawing.Point(507, 283);
            this.txtDINSS.Name = "txtDINSS";
            this.txtDINSS.Size = new System.Drawing.Size(133, 20);
            this.txtDINSS.TabIndex = 23;
            // 
            // txtDIRPF
            // 
            this.txtDIRPF.Enabled = false;
            this.txtDIRPF.Location = new System.Drawing.Point(507, 321);
            this.txtDIRPF.Name = "txtDIRPF";
            this.txtDIRPF.Size = new System.Drawing.Size(133, 20);
            this.txtDIRPF.TabIndex = 24;
            // 
            // txtSFamilia
            // 
            this.txtSFamilia.Enabled = false;
            this.txtSFamilia.Location = new System.Drawing.Point(220, 358);
            this.txtSFamilia.Name = "txtSFamilia";
            this.txtSFamilia.Size = new System.Drawing.Size(134, 20);
            this.txtSFamilia.TabIndex = 25;
            // 
            // txtSLiquido
            // 
            this.txtSLiquido.Enabled = false;
            this.txtSLiquido.Location = new System.Drawing.Point(506, 358);
            this.txtSLiquido.Name = "txtSLiquido";
            this.txtSLiquido.Size = new System.Drawing.Size(134, 20);
            this.txtSLiquido.TabIndex = 26;
            // 
            // BtnLimpar
            // 
            this.BtnLimpar.Location = new System.Drawing.Point(279, 173);
            this.BtnLimpar.Name = "BtnLimpar";
            this.BtnLimpar.Size = new System.Drawing.Size(104, 23);
            this.BtnLimpar.TabIndex = 27;
            this.BtnLimpar.Text = "Limpar Campos";
            this.BtnLimpar.UseVisualStyleBackColor = true;
            this.BtnLimpar.Click += new System.EventHandler(this.BtnLimpar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtnLimpar);
            this.Controls.Add(this.txtSLiquido);
            this.Controls.Add(this.txtSFamilia);
            this.Controls.Add(this.txtDIRPF);
            this.Controls.Add(this.txtDINSS);
            this.Controls.Add(this.CkbxCasado);
            this.Controls.Add(this.txtAINSS);
            this.Controls.Add(this.txtAIRPF);
            this.Controls.Add(this.mskbxSBruto);
            this.Controls.Add(this.labelSLiquido);
            this.Controls.Add(this.labelMensagem);
            this.Controls.Add(this.labelSFamilia);
            this.Controls.Add(this.labelDIRPF);
            this.Controls.Add(this.labelAIRPF);
            this.Controls.Add(this.labelDINSS);
            this.Controls.Add(this.labelAINSS);
            this.Controls.Add(this.BtnCalcular);
            this.Controls.Add(this.GpxGenero);
            this.Controls.Add(this.CbxFilhos);
            this.Controls.Add(this.txtnome);
            this.Controls.Add(this.labelFilhos);
            this.Controls.Add(this.labelSBruto);
            this.Controls.Add(this.labelNome);
            this.Name = "Form1";
            this.Text = "Form1";
            this.GpxGenero.ResumeLayout(false);
            this.GpxGenero.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelNome;
        private System.Windows.Forms.Label labelSBruto;
        private System.Windows.Forms.Label labelFilhos;
        private System.Windows.Forms.TextBox txtnome;
        private System.Windows.Forms.GroupBox GpxGenero;
        private System.Windows.Forms.RadioButton RbtnF;
        private System.Windows.Forms.RadioButton RbtnM;
        private System.Windows.Forms.Button BtnCalcular;
        private System.Windows.Forms.Label labelAINSS;
        private System.Windows.Forms.Label labelDINSS;
        private System.Windows.Forms.Label labelAIRPF;
        private System.Windows.Forms.Label labelDIRPF;
        private System.Windows.Forms.Label labelSFamilia;
        private System.Windows.Forms.Label labelMensagem;
        private System.Windows.Forms.Label labelSLiquido;
        private System.Windows.Forms.MaskedTextBox mskbxSBruto;
        private System.Windows.Forms.TextBox txtAIRPF;
        private System.Windows.Forms.TextBox txtAINSS;
        private System.Windows.Forms.CheckBox CkbxCasado;
        private System.Windows.Forms.TextBox txtDINSS;
        private System.Windows.Forms.TextBox txtDIRPF;
        private System.Windows.Forms.TextBox txtSFamilia;
        private System.Windows.Forms.TextBox txtSLiquido;
        private System.Windows.Forms.ComboBox CbxFilhos;
        private System.Windows.Forms.Button BtnLimpar;
    }
}

