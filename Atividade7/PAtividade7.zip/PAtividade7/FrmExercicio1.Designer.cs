﻿
namespace PAtividade7
{
    partial class FrmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnContPares = new System.Windows.Forms.Button();
            this.BtnContR = new System.Windows.Forms.Button();
            this.BtnContEspaco = new System.Windows.Forms.Button();
            this.RchTxtCaracteres = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // BtnContPares
            // 
            this.BtnContPares.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnContPares.Location = new System.Drawing.Point(453, 268);
            this.BtnContPares.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnContPares.Name = "BtnContPares";
            this.BtnContPares.Size = new System.Drawing.Size(106, 78);
            this.BtnContPares.TabIndex = 7;
            this.BtnContPares.Text = "Conta pares de caracter";
            this.BtnContPares.UseVisualStyleBackColor = true;
            this.BtnContPares.Click += new System.EventHandler(this.BtnContPares_Click);
            // 
            // BtnContR
            // 
            this.BtnContR.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnContR.Location = new System.Drawing.Point(250, 268);
            this.BtnContR.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnContR.Name = "BtnContR";
            this.BtnContR.Size = new System.Drawing.Size(106, 78);
            this.BtnContR.TabIndex = 6;
            this.BtnContR.Text = "Número de caracter \"R\"";
            this.BtnContR.UseVisualStyleBackColor = true;
            this.BtnContR.Click += new System.EventHandler(this.BtnContR_Click);
            // 
            // BtnContEspaco
            // 
            this.BtnContEspaco.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnContEspaco.Location = new System.Drawing.Point(44, 268);
            this.BtnContEspaco.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnContEspaco.Name = "BtnContEspaco";
            this.BtnContEspaco.Size = new System.Drawing.Size(106, 78);
            this.BtnContEspaco.TabIndex = 5;
            this.BtnContEspaco.Text = "Conta espaço em branco";
            this.BtnContEspaco.UseVisualStyleBackColor = true;
            this.BtnContEspaco.Click += new System.EventHandler(this.BtnContEspaco_Click);
            // 
            // RchTxtCaracteres
            // 
            this.RchTxtCaracteres.Location = new System.Drawing.Point(44, 24);
            this.RchTxtCaracteres.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.RchTxtCaracteres.Name = "RchTxtCaracteres";
            this.RchTxtCaracteres.Size = new System.Drawing.Size(516, 210);
            this.RchTxtCaracteres.TabIndex = 4;
            this.RchTxtCaracteres.Text = "";
            // 
            // FrmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.BtnContPares);
            this.Controls.Add(this.BtnContR);
            this.Controls.Add(this.BtnContEspaco);
            this.Controls.Add(this.RchTxtCaracteres);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "FrmExercicio1";
            this.Text = "FrmExercicio1";
            this.Load += new System.EventHandler(this.FrmExercicio1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnContPares;
        private System.Windows.Forms.Button BtnContR;
        private System.Windows.Forms.Button BtnContEspaco;
        private System.Windows.Forms.RichTextBox RchTxtCaracteres;
    }
}