﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade7
{
    public partial class FrmExercicio1 : Form
    {
        public FrmExercicio1()
        {
            InitializeComponent();
        }

        private void BtnContEspaco_Click(object sender, EventArgs e)
        {
            int Cont = 0;
            int i = 0;
            if (RchTxtCaracteres.Text == "")
                MessageBox.Show("Caixa de Texto vazia");
            else
            {
                while (i < RchTxtCaracteres.Text.Length)  
                {                                        
                    if (char.IsWhiteSpace(RchTxtCaracteres.Text[i])) 
                    {                                               
                        Cont++;                                  
                    }
                    i++;
                }
            }
            if (Cont == 1)
                MessageBox.Show("Existe apenas 1 Espaço em branco");
            else if (Cont > 1)
                MessageBox.Show("Existe " + Cont + " Espaços em branco");
            else
                MessageBox.Show("Não há nenhuma posição em Branco");
        }

        private void BtnContR_Click(object sender, EventArgs e)
        {
            int Cont = 0;
            if (RchTxtCaracteres.Text == "")
                MessageBox.Show("Caixa de Texto vazia");
            else
            {

                foreach(char i in RchTxtCaracteres.Text)
                {
                    if (char.ToLower(i) == 'r') 
                        Cont++;
                }

                if (Cont == 1)
                    MessageBox.Show("Existe apenas uma Letra R na Frase");
                else if (Cont > 1)
                    MessageBox.Show("Existe " + Cont + " R na Frase");
                else
                    MessageBox.Show("Não há nenhum R na Frase");


            }
        }

        private void BtnContPares_Click(object sender, EventArgs e)
        {
            int Cont = 0;

            for (int i = 0; i < RchTxtCaracteres.Text.Length; i++)
            {
                if (RchTxtCaracteres.Text.Length != i + 1)
                {                                         
                    if ((RchTxtCaracteres.Text[i] == RchTxtCaracteres.Text[i + 1]))
                    {
                        Cont++;
                    }
                }
            }

            if (Cont == 1)
                MessageBox.Show("Existe 1 Par de Letras");
            else if (Cont > 1)
                MessageBox.Show("Existe " + Cont + " Pares de Letras");
            else
                MessageBox.Show("Não há nenhum par de Letras");

        }

        private void FrmExercicio1_Load(object sender, EventArgs e)
        {

        }
    }
}
