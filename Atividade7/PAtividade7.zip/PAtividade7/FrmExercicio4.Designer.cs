﻿
namespace PAtividade7
{
    partial class FrmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalculaSalario = new System.Windows.Forms.Button();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblCargo = new System.Windows.Forms.Label();
            this.lblSalario = new System.Windows.Forms.Label();
            this.lblGratificação = new System.Windows.Forms.Label();
            this.lblProdução = new System.Windows.Forms.Label();
            this.lblInscrição = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtCargo = new System.Windows.Forms.TextBox();
            this.masktxtGratificacao = new System.Windows.Forms.MaskedTextBox();
            this.masktxtProducao = new System.Windows.Forms.MaskedTextBox();
            this.masktxtInscricao = new System.Windows.Forms.MaskedTextBox();
            this.mskbx1 = new System.Windows.Forms.MaskedTextBox();
            this.SuspendLayout();
            // 
            // btnCalculaSalario
            // 
            this.btnCalculaSalario.Location = new System.Drawing.Point(282, 249);
            this.btnCalculaSalario.Name = "btnCalculaSalario";
            this.btnCalculaSalario.Size = new System.Drawing.Size(75, 23);
            this.btnCalculaSalario.TabIndex = 0;
            this.btnCalculaSalario.Text = "Calcular";
            this.btnCalculaSalario.UseVisualStyleBackColor = true;
            this.btnCalculaSalario.Click += new System.EventHandler(this.btnCalculaSalario_Click);
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(226, 27);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(35, 13);
            this.lblNome.TabIndex = 1;
            this.lblNome.Text = "Nome";
            // 
            // lblCargo
            // 
            this.lblCargo.AutoSize = true;
            this.lblCargo.Location = new System.Drawing.Point(226, 60);
            this.lblCargo.Name = "lblCargo";
            this.lblCargo.Size = new System.Drawing.Size(35, 13);
            this.lblCargo.TabIndex = 2;
            this.lblCargo.Text = "Cargo";
            // 
            // lblSalario
            // 
            this.lblSalario.AutoSize = true;
            this.lblSalario.Location = new System.Drawing.Point(226, 97);
            this.lblSalario.Name = "lblSalario";
            this.lblSalario.Size = new System.Drawing.Size(39, 13);
            this.lblSalario.TabIndex = 3;
            this.lblSalario.Text = "Salário";
            // 
            // lblGratificação
            // 
            this.lblGratificação.AutoSize = true;
            this.lblGratificação.Location = new System.Drawing.Point(226, 124);
            this.lblGratificação.Name = "lblGratificação";
            this.lblGratificação.Size = new System.Drawing.Size(64, 13);
            this.lblGratificação.TabIndex = 4;
            this.lblGratificação.Text = "Gratificação";
            // 
            // lblProdução
            // 
            this.lblProdução.AutoSize = true;
            this.lblProdução.Location = new System.Drawing.Point(226, 158);
            this.lblProdução.Name = "lblProdução";
            this.lblProdução.Size = new System.Drawing.Size(53, 13);
            this.lblProdução.TabIndex = 5;
            this.lblProdução.Text = "Produção";
            // 
            // lblInscrição
            // 
            this.lblInscrição.AutoSize = true;
            this.lblInscrição.Location = new System.Drawing.Point(226, 188);
            this.lblInscrição.Name = "lblInscrição";
            this.lblInscrição.Size = new System.Drawing.Size(50, 13);
            this.lblInscrição.TabIndex = 6;
            this.lblInscrição.Text = "Inscrição";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(312, 24);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 20);
            this.txtNome.TabIndex = 7;
            // 
            // txtCargo
            // 
            this.txtCargo.Location = new System.Drawing.Point(312, 57);
            this.txtCargo.Name = "txtCargo";
            this.txtCargo.Size = new System.Drawing.Size(100, 20);
            this.txtCargo.TabIndex = 8;
            // 
            // masktxtGratificacao
            // 
            this.masktxtGratificacao.Location = new System.Drawing.Point(312, 117);
            this.masktxtGratificacao.Name = "masktxtGratificacao";
            this.masktxtGratificacao.Size = new System.Drawing.Size(100, 20);
            this.masktxtGratificacao.TabIndex = 10;
            // 
            // masktxtProducao
            // 
            this.masktxtProducao.Location = new System.Drawing.Point(312, 151);
            this.masktxtProducao.Name = "masktxtProducao";
            this.masktxtProducao.Size = new System.Drawing.Size(100, 20);
            this.masktxtProducao.TabIndex = 11;
            // 
            // masktxtInscricao
            // 
            this.masktxtInscricao.Location = new System.Drawing.Point(312, 188);
            this.masktxtInscricao.Name = "masktxtInscricao";
            this.masktxtInscricao.Size = new System.Drawing.Size(100, 20);
            this.masktxtInscricao.TabIndex = 12;
            // 
            // mskbx1
            // 
            this.mskbx1.Location = new System.Drawing.Point(312, 94);
            this.mskbx1.Name = "mskbx1";
            this.mskbx1.Size = new System.Drawing.Size(100, 20);
            this.mskbx1.TabIndex = 13;
            // 
            // FrmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.mskbx1);
            this.Controls.Add(this.masktxtInscricao);
            this.Controls.Add(this.masktxtProducao);
            this.Controls.Add(this.masktxtGratificacao);
            this.Controls.Add(this.txtCargo);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblInscrição);
            this.Controls.Add(this.lblProdução);
            this.Controls.Add(this.lblGratificação);
            this.Controls.Add(this.lblSalario);
            this.Controls.Add(this.lblCargo);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.btnCalculaSalario);
            this.Name = "FrmExercicio4";
            this.Text = "FrmExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCalculaSalario;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblCargo;
        private System.Windows.Forms.Label lblSalario;
        private System.Windows.Forms.Label lblGratificação;
        private System.Windows.Forms.Label lblProdução;
        private System.Windows.Forms.Label lblInscrição;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtCargo;
        private System.Windows.Forms.MaskedTextBox masktxtGratificacao;
        private System.Windows.Forms.MaskedTextBox masktxtProducao;
        private System.Windows.Forms.MaskedTextBox masktxtInscricao;
        private System.Windows.Forms.MaskedTextBox mskbx1;
    }
}