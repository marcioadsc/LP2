﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMC
{
    public partial class Form1 : Form
    {
        double altura, peso, pesoideal;

        private void Limpar_Click(object sender, EventArgs e)
        {
            msktxtbox1.Clear();
            msktxtbox3.Clear();
            msktxtbox1.Focus();
        }

        private void Calcular_Click(object sender, EventArgs e)
        {
            if (double.TryParse(msktxtbox1.Text, out altura) &&
                double.TryParse(msktxtbox3.Text, out peso))
            {
                if (RbtnM.Checked)
                {
                    pesoideal = (72.7 * altura) - 58;
                    pesoideal = Math.Round(pesoideal, 2);
                }
                else
                {
                    pesoideal = (62.1 * altura) - 44.7;
                    pesoideal = Math.Round(pesoideal, 2);
                }

                if (peso < pesoideal)
                    MessageBox.Show("Coma bastante massas e doces!");
                else
                if (peso > pesoideal)
                    MessageBox.Show("Regime Obrigatório!");
                else
                    MessageBox.Show("Você está com o peso ideal!");

            }
            else
                MessageBox.Show("Entre com valores validos!");
        }

        public Form1()
        {
            InitializeComponent();
        }

        
    }
}
