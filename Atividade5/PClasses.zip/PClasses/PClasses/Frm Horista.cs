﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PClasses
{
    public partial class Frm_Horista : Form
    {
        public Frm_Horista()
        {
            InitializeComponent();
        }

        private void BtnInstHorista_Click(object sender, EventArgs e)
        {
            Horista objHorista = new Horista();

            //set
            objHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objHorista.NomeEmpregado = txtNome.Text;
            objHorista.SalarioHora = Convert.ToDouble(txtSHora.Text);
            objHorista.NumHora = Convert.ToDouble(txtQtdeHoras.Text);
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);//dd/mm/aaaa
            objHorista.DiasFalta = Convert.ToInt32(txtQtdeFaltas.Text);

            //get
            MessageBox.Show("Matrícula Nº " + objHorista.Matricula + "\n" +
                            "Nome do Funcionário: " + objHorista.NomeEmpregado + "\n" +
                            "Data de Admissão: " + objHorista.DataEntradaEmpresa.ToShortDateString() + "\n" +
                            "Salário Bruto: " + objHorista.SalarioBruto().ToString("N2") + "\n" +
                            "Tempo de Empresa (em dias): " + objHorista.TempoTrabalho());
        }
    }
}
