﻿
namespace PClasses
{
    partial class FrmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelMatricula = new System.Windows.Forms.Label();
            this.labelNome = new System.Windows.Forms.Label();
            this.labelSBruto = new System.Windows.Forms.Label();
            this.labelEntradaEmpresa = new System.Windows.Forms.Label();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtSalario = new System.Windows.Forms.TextBox();
            this.txtEntradaEmpresa = new System.Windows.Forms.TextBox();
            this.BtnInstMensalista = new System.Windows.Forms.Button();
            this.BtnInstParametro = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelMatricula
            // 
            this.labelMatricula.AutoSize = true;
            this.labelMatricula.Location = new System.Drawing.Point(169, 40);
            this.labelMatricula.Name = "labelMatricula";
            this.labelMatricula.Size = new System.Drawing.Size(140, 15);
            this.labelMatricula.TabIndex = 0;
            this.labelMatricula.Text = "Matrícula do Funcionário";
            // 
            // labelNome
            // 
            this.labelNome.AutoSize = true;
            this.labelNome.Location = new System.Drawing.Point(169, 85);
            this.labelNome.Name = "labelNome";
            this.labelNome.Size = new System.Drawing.Size(40, 15);
            this.labelNome.TabIndex = 1;
            this.labelNome.Text = "Nome";
            // 
            // labelSBruto
            // 
            this.labelSBruto.AutoSize = true;
            this.labelSBruto.Location = new System.Drawing.Point(169, 137);
            this.labelSBruto.Name = "labelSBruto";
            this.labelSBruto.Size = new System.Drawing.Size(74, 15);
            this.labelSBruto.TabIndex = 2;
            this.labelSBruto.Text = "Salário Bruto";
            // 
            // labelEntradaEmpresa
            // 
            this.labelEntradaEmpresa.AutoSize = true;
            this.labelEntradaEmpresa.Location = new System.Drawing.Point(169, 186);
            this.labelEntradaEmpresa.Name = "labelEntradaEmpresa";
            this.labelEntradaEmpresa.Size = new System.Drawing.Size(154, 15);
            this.labelEntradaEmpresa.TabIndex = 3;
            this.labelEntradaEmpresa.Text = "Data de Entrada na Empresa";
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(372, 37);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(100, 23);
            this.txtMatricula.TabIndex = 4;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(372, 82);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 23);
            this.txtNome.TabIndex = 5;
            // 
            // txtSalario
            // 
            this.txtSalario.Location = new System.Drawing.Point(372, 134);
            this.txtSalario.Name = "txtSalario";
            this.txtSalario.Size = new System.Drawing.Size(100, 23);
            this.txtSalario.TabIndex = 6;
            // 
            // txtEntradaEmpresa
            // 
            this.txtEntradaEmpresa.Location = new System.Drawing.Point(372, 183);
            this.txtEntradaEmpresa.Name = "txtEntradaEmpresa";
            this.txtEntradaEmpresa.Size = new System.Drawing.Size(100, 23);
            this.txtEntradaEmpresa.TabIndex = 7;
            // 
            // BtnInstMensalista
            // 
            this.BtnInstMensalista.Location = new System.Drawing.Point(169, 245);
            this.BtnInstMensalista.Name = "BtnInstMensalista";
            this.BtnInstMensalista.Size = new System.Drawing.Size(124, 64);
            this.BtnInstMensalista.TabIndex = 8;
            this.BtnInstMensalista.Text = "Instanciar Mensalista";
            this.BtnInstMensalista.UseVisualStyleBackColor = true;
            this.BtnInstMensalista.Click += new System.EventHandler(this.BtnInstMensalista_Click);
            // 
            // BtnInstParametro
            // 
            this.BtnInstParametro.Location = new System.Drawing.Point(343, 245);
            this.BtnInstParametro.Name = "BtnInstParametro";
            this.BtnInstParametro.Size = new System.Drawing.Size(129, 64);
            this.BtnInstParametro.TabIndex = 9;
            this.BtnInstParametro.Text = "Instanciar Mensalista com Parâmetros";
            this.BtnInstParametro.UseVisualStyleBackColor = true;
            this.BtnInstParametro.Click += new System.EventHandler(this.BtnInstParametro_Click);
            // 
            // FrmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtnInstParametro);
            this.Controls.Add(this.BtnInstMensalista);
            this.Controls.Add(this.txtEntradaEmpresa);
            this.Controls.Add(this.txtSalario);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.labelEntradaEmpresa);
            this.Controls.Add(this.labelSBruto);
            this.Controls.Add(this.labelNome);
            this.Controls.Add(this.labelMatricula);
            this.Name = "FrmMensalista";
            this.Text = "FrmMensalista";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelMatricula;
        private System.Windows.Forms.Label labelNome;
        private System.Windows.Forms.Label labelSBruto;
        private System.Windows.Forms.Label labelEntradaEmpresa;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtSalario;
        private System.Windows.Forms.TextBox txtEntradaEmpresa;
        private System.Windows.Forms.Button BtnInstMensalista;
        private System.Windows.Forms.Button BtnInstParametro;
    }
}