﻿
namespace PClasses
{
    partial class Frm_Horista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelMatricula = new System.Windows.Forms.Label();
            this.labelNome = new System.Windows.Forms.Label();
            this.labelSHora = new System.Windows.Forms.Label();
            this.labelQtdeHora = new System.Windows.Forms.Label();
            this.labelData = new System.Windows.Forms.Label();
            this.labelQtdeFaltas = new System.Windows.Forms.Label();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtSHora = new System.Windows.Forms.TextBox();
            this.txtQtdeHoras = new System.Windows.Forms.TextBox();
            this.txtData = new System.Windows.Forms.TextBox();
            this.txtQtdeFaltas = new System.Windows.Forms.TextBox();
            this.BtnInstHorista = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelMatricula
            // 
            this.labelMatricula.AutoSize = true;
            this.labelMatricula.Location = new System.Drawing.Point(185, 25);
            this.labelMatricula.Name = "labelMatricula";
            this.labelMatricula.Size = new System.Drawing.Size(57, 15);
            this.labelMatricula.TabIndex = 0;
            this.labelMatricula.Text = "Matrícula";
            // 
            // labelNome
            // 
            this.labelNome.AutoSize = true;
            this.labelNome.Location = new System.Drawing.Point(185, 65);
            this.labelNome.Name = "labelNome";
            this.labelNome.Size = new System.Drawing.Size(123, 15);
            this.labelNome.TabIndex = 1;
            this.labelNome.Text = "Nome do Funcionário";
            // 
            // labelSHora
            // 
            this.labelSHora.AutoSize = true;
            this.labelSHora.Location = new System.Drawing.Point(185, 110);
            this.labelSHora.Name = "labelSHora";
            this.labelSHora.Size = new System.Drawing.Size(90, 15);
            this.labelSHora.TabIndex = 2;
            this.labelSHora.Text = "Salário por hora";
            // 
            // labelQtdeHora
            // 
            this.labelQtdeHora.AutoSize = true;
            this.labelQtdeHora.Location = new System.Drawing.Point(185, 146);
            this.labelQtdeHora.Name = "labelQtdeHora";
            this.labelQtdeHora.Size = new System.Drawing.Size(117, 15);
            this.labelQtdeHora.TabIndex = 3;
            this.labelQtdeHora.Text = "Quantidade de horas";
            // 
            // labelData
            // 
            this.labelData.AutoSize = true;
            this.labelData.Location = new System.Drawing.Point(185, 190);
            this.labelData.Name = "labelData";
            this.labelData.Size = new System.Drawing.Size(102, 15);
            this.labelData.TabIndex = 4;
            this.labelData.Text = "Data de Admissão";
            // 
            // labelQtdeFaltas
            // 
            this.labelQtdeFaltas.AutoSize = true;
            this.labelQtdeFaltas.Location = new System.Drawing.Point(185, 226);
            this.labelQtdeFaltas.Name = "labelQtdeFaltas";
            this.labelQtdeFaltas.Size = new System.Drawing.Size(118, 15);
            this.labelQtdeFaltas.TabIndex = 5;
            this.labelQtdeFaltas.Text = "Quantidade de Faltas";
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(310, 22);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(100, 23);
            this.txtMatricula.TabIndex = 6;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(310, 62);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 23);
            this.txtNome.TabIndex = 7;
            // 
            // txtSHora
            // 
            this.txtSHora.Location = new System.Drawing.Point(310, 107);
            this.txtSHora.Name = "txtSHora";
            this.txtSHora.Size = new System.Drawing.Size(100, 23);
            this.txtSHora.TabIndex = 8;
            // 
            // txtQtdeHoras
            // 
            this.txtQtdeHoras.Location = new System.Drawing.Point(310, 143);
            this.txtQtdeHoras.Name = "txtQtdeHoras";
            this.txtQtdeHoras.Size = new System.Drawing.Size(100, 23);
            this.txtQtdeHoras.TabIndex = 9;
            // 
            // txtData
            // 
            this.txtData.Location = new System.Drawing.Point(310, 187);
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(100, 23);
            this.txtData.TabIndex = 10;
            // 
            // txtQtdeFaltas
            // 
            this.txtQtdeFaltas.Location = new System.Drawing.Point(310, 223);
            this.txtQtdeFaltas.Name = "txtQtdeFaltas";
            this.txtQtdeFaltas.Size = new System.Drawing.Size(100, 23);
            this.txtQtdeFaltas.TabIndex = 11;
            // 
            // BtnInstHorista
            // 
            this.BtnInstHorista.Location = new System.Drawing.Point(254, 265);
            this.BtnInstHorista.Name = "BtnInstHorista";
            this.BtnInstHorista.Size = new System.Drawing.Size(93, 63);
            this.BtnInstHorista.TabIndex = 12;
            this.BtnInstHorista.Text = "Instanciar Horista";
            this.BtnInstHorista.UseVisualStyleBackColor = true;
            this.BtnInstHorista.Click += new System.EventHandler(this.BtnInstHorista_Click);
            // 
            // Frm_Horista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtnInstHorista);
            this.Controls.Add(this.txtQtdeFaltas);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.txtQtdeHoras);
            this.Controls.Add(this.txtSHora);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.labelQtdeFaltas);
            this.Controls.Add(this.labelData);
            this.Controls.Add(this.labelQtdeHora);
            this.Controls.Add(this.labelSHora);
            this.Controls.Add(this.labelNome);
            this.Controls.Add(this.labelMatricula);
            this.Name = "Frm_Horista";
            this.Text = "Frm_Horista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelMatricula;
        private System.Windows.Forms.Label labelNome;
        private System.Windows.Forms.Label labelSHora;
        private System.Windows.Forms.Label labelQtdeHora;
        private System.Windows.Forms.Label labelData;
        private System.Windows.Forms.Label labelQtdeFaltas;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtSHora;
        private System.Windows.Forms.TextBox txtQtdeHoras;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.TextBox txtQtdeFaltas;
        private System.Windows.Forms.Button BtnInstHorista;
    }
}