﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PClasses
{
    class Horista : Empregado
    {
        public double SalarioHora { get; set; }

        public double NumHora { get; set; }

        public int DiasFalta { get; set; }

        public override double SalarioBruto()
        {
            return (SalarioHora * NumHora);
        }

        public override int TempoTrabalho()
        {
            TimeSpan span = DateTime.Today.Subtract(DataEntradaEmpresa);
            return (Convert.ToInt32(span.Days) - DiasFalta);
        }
    }
}
